/* main.js — improved pro flow */
const cardRanks = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]; // A lowest
const WIN_MULTIPLIER = 1.90;
const MIN_BET = 30;

let userId = document.getElementById('userId')?.innerText.split(':')[1]?.trim() || 'guest63837';
let balance = 41;
let adminProfit = 0;
let roundNo = 1;
let history = [];
let botActivity = [];
let bots = [
  {name:'PlayerX', coins:120000},
  {name:'LuckyCat', coins:90000},
  {name:'TigerKing', coins:110000}
];

let bettingOpen = false;
let roundTimer = null;
let firstRound = true;

// utility
function el(id){ return document.getElementById(id); }
function updateUI(){
  el('balance').innerText = `Balance: ${balance}`;
  el('adminProfit').innerText = `Admin: ${adminProfit}`;
  el('roundNo').innerText = `Round: ${roundNo}`;
  renderHistory();
  renderBots();
}

// show toast (small)
function toast(msg){ console.log('TOAST:',msg); /* could implement visible toast */ }

// generate random card (returns rank string)
function randomCard(){ return cardRanks[Math.floor(Math.random()*cardRanks.length)]; }

// determine winner using card ranks
function determineWinner(dragonCard, tigerCard){
  const d = cardRanks.indexOf(dragonCard);
  const t = cardRanks.indexOf(tigerCard);
  if(d>t) return 'Dragon';
  if(t>d) return 'Tiger';
  return 'Tie';
}

// start betting round with duration (seconds)
function startRound(){
  bettingOpen = true;
  const duration = firstRound ? 15 : 14;
  let timer = duration;
  el('status').innerText = '👉 Place your bet';
  el('timer').innerText = `⏳ ${timer}`;
  enableButtons(true);
  // reset card backs
  resetCards();

  // clear existing interval
  if(roundTimer) clearInterval(roundTimer);
  roundTimer = setInterval(()=>{
    timer--;
    el('timer').innerText = `⏳ ${timer}`;
    if(timer <= 0){
      clearInterval(roundTimer);
      stopBetting();
    }
  },1000);
}

// stop betting and proceed to reveal
function stopBetting(){
  bettingOpen = false;
  enableButtons(false);
  el('status').innerText = '❌ STOP BETTING';
  el('timer').innerText = '⏱ Revealing...';
  // brief pause then reveal cards
  setTimeout(()=> revealAndResolve(), 900);
}

// reveal flow: reveal cards, show VS, then show result and payouts
function revealAndResolve(){
  // pick cards
  const dragonCard = randomCard();
  const tigerCard = randomCard();
  // show card texts & attempt to set images
  setCardDisplay('dragon', dragonCard);
  setCardDisplay('tiger', tigerCard);

  // add bot random bets for the round (visual)
  simulateBotBets();

  // Show "Dragon VS Tiger" for 4s, then show result
  el('status').innerText = '🔥 Dragon VS Tiger 🔥';
  el('timer').innerText = '⏳ 4';
  let t = 4;
  const vsInterval = setInterval(()=>{
    t--; el('timer').innerText = `⏳ ${t}`;
    if(t<=0){ clearInterval(vsInterval);
      // determine winner
      const winner = determineWinner(dragonCard, tigerCard);
      let resultText = winner === 'Tie' ? "It's a Tie!" : `${winner} Wins!`;
      el('status').innerText = resultText;
      // payout handling for user bets stored by placeBet call
      // placeBet stored a pendingBet object; we'll process it here
      processPendingBets(winner);
      // update history & UI
      addHistory({round:roundNo, dragon:dragonCard, tiger:tigerCard, winner});
      roundNo++; firstRound = false;
      // start next round after short pause (3s)
      setTimeout(()=>{ updateUI(); startRound(); }, 3000);
    }
  },1000);
}

// helper to set card text & image (if exists)
function setCardDisplay(side, cardRank){
  const imgEl = el(side + 'CardImg');
  const textEl = el(side + 'CardText');
  // update text
  if(textEl) textEl.innerText = cardRank;
  // if image for rank exists (e.g. assets/images/cards/A.png), set it
  const imagePath = `assets/images/cards/${cardRank}.png`;
  fetch(imagePath, {method:'HEAD'}).then(res=>{
    if(res.ok){ imgEl.src = imagePath; } else { imgEl.src = 'assets/images/cardface.png'; }
    // add reveal class for flip
    imgEl.classList.add('reveal');
    setTimeout(()=> imgEl.classList.remove('reveal'), 900);
  }).catch(()=>{ imgEl.src = 'assets/images/cardface.png'; imgEl.classList.add('reveal'); setTimeout(()=> imgEl.classList.remove('reveal'),900); });
}

// reset cards to back
function resetCards(){
  const dImg = el('dragonCardImg'); const tImg = el('tigerCardImg');
  if(dImg) dImg.src = 'assets/images/back.png';
  if(tImg) tImg.src = 'assets/images/back.png';
  el('dragonCardText').innerText=''; el('tigerCardText').innerText='';
}

// simple pending bet storage (only one user bet per round)
let pendingBet = null;
function placeBet(choice){
  if(!bettingOpen){ toast('Betting closed'); return; }
  const input = el('betInput');
  let bet = parseInt(input.value) || MIN_BET;
  if(bet < MIN_BET){ toast('Minimum bet is 30'); input.value = MIN_BET; return; }
  if(bet > balance){ toast('Insufficient balance'); return; }
  // store pending bet for processing on reveal
  pendingBet = { userId, choice, bet };
  // lock current bet input visually
  toast(`Bet placed ${choice} (-${bet})`);
  // temporary deduct bet to avoid double-betting
  balance -= bet; updateUI();
}

// process pending bets when winner known
function processPendingBets(winner){
  if(pendingBet){
    const p = pendingBet;
    if(winner === 'Tie'){
      // return bet
      balance += p.bet;
    } else if(p.choice === winner){
      // user wins: payout = floor(bet * 1.90)
      const payout = Math.floor(p.bet * WIN_MULTIPLIER);
      balance += payout;
      // admin profit is (payout - bet)
      adminProfit += (payout - p.bet);
    } else {
      // user lost already deducted bet; admin gets bet
      adminProfit += p.bet;
    }
    // push to history display
    addHistoryEntry(`${p.userId} bet ${p.bet} on ${p.choice} → ${ (winner===p.choice)? 'WON':'LOST' }`);
    pendingBet = null;
  } else {
    // no user bet this round
  }
  updateUI();
}

// simulate fake bots visually & update admin profit
function simulateBotBets(){
  const botList = el('botActivity');
  // clear some old activity
  if(botActivity.length>6) botActivity = botActivity.slice(-6);
  // each bot places random bet/choice and update adminProfit appropriately
  bots.forEach(b=>{
    const bet = Math.floor(Math.random()*5000)+30;
    const choice = Math.random()<0.5 ? 'Dragon' : 'Tiger';
    // store visually
    botActivity.unshift(`${b.name} bet ${bet} on ${choice}`);
    if(botActivity.length>6) botActivity.pop();
    // determine immediate outcome later after winner known — we will adjust adminProfit in processPendingBets stage
    // For simpler visual, assume half wins half lose: update coins minimally
    if(Math.random()<0.5){ b.coins += Math.floor(bet * WIN_MULTIPLIER); adminProfit += Math.floor(bet*(WIN_MULTIPLIER-1)); }
    else { b.coins -= bet; adminProfit += bet; }
  });
  renderBots();
}

// history helpers
function addHistory(obj){
  history.unshift(`#${obj.round}: D-${obj.dragon} | T-${obj.tiger} → ${obj.winner}`);
  if(history.length>5) history.pop();
  renderHistory();
}
function addHistoryEntry(text){
  history.unshift(text);
  if(history.length>5) history.pop();
  renderHistory();
}
function renderHistory(){
  const ul = el('historyList'); if(!ul) return;
  ul.innerHTML = history.map(h=>`<li>${h}</li>`).join('');
}
function renderBots(){
  const ul = el('botActivity');
  if(!ul) return;
  ul.innerHTML = botActivity.slice(0,6).map(a=>`<li>${a}</li>`).join('');
}

// enable or disable bet buttons
function enableButtons(enable){
  el('dragonBtn').disabled = !enable;
  el('tigerBtn').disabled = !enable;
  el('betInput').disabled = !enable;
}

// attach click handlers (already inline in HTML but keep safe)
document.getElementById('dragonBtn').addEventListener('click', ()=> placeBet('Dragon'));
document.getElementById('tigerBtn').addEventListener('click', ()=> placeBet('Tiger'));

// init
function init(){
  // set user id from DOM if present
  const uidText = el('userId').innerText || 'guest63837';
  userId = uidText.includes(':') ? uidText.split(':')[1].trim() : uidText;
  updateUI();
  resetCards();
  startRound();
}
window.addEventListener('load', init);